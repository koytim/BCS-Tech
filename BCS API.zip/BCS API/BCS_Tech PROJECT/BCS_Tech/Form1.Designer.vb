﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Book_Table = New System.Windows.Forms.DataGridView()
        Me.NameTXT = New System.Windows.Forms.TextBox()
        Me.AddBTN = New System.Windows.Forms.Button()
        Me.UpdateBTN = New System.Windows.Forms.Button()
        Me.DeleteBTN = New System.Windows.Forms.Button()
        Me.AuthorTXT = New System.Windows.Forms.TextBox()
        Me.PriceTXT = New System.Windows.Forms.TextBox()
        Me.StockTXT = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.SearchIDTXT = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        CType(Me.Book_Table, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Book_Table
        '
        Me.Book_Table.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Book_Table.Location = New System.Drawing.Point(12, 69)
        Me.Book_Table.Name = "Book_Table"
        Me.Book_Table.Size = New System.Drawing.Size(522, 119)
        Me.Book_Table.TabIndex = 0
        '
        'NameTXT
        '
        Me.NameTXT.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NameTXT.Location = New System.Drawing.Point(35, 214)
        Me.NameTXT.Name = "NameTXT"
        Me.NameTXT.Size = New System.Drawing.Size(100, 22)
        Me.NameTXT.TabIndex = 1
        '
        'AddBTN
        '
        Me.AddBTN.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddBTN.Location = New System.Drawing.Point(79, 251)
        Me.AddBTN.Name = "AddBTN"
        Me.AddBTN.Size = New System.Drawing.Size(96, 29)
        Me.AddBTN.TabIndex = 3
        Me.AddBTN.Text = "ADD"
        Me.AddBTN.UseVisualStyleBackColor = True
        '
        'UpdateBTN
        '
        Me.UpdateBTN.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UpdateBTN.Location = New System.Drawing.Point(215, 251)
        Me.UpdateBTN.Name = "UpdateBTN"
        Me.UpdateBTN.Size = New System.Drawing.Size(96, 29)
        Me.UpdateBTN.TabIndex = 4
        Me.UpdateBTN.Text = "UPDATE"
        Me.UpdateBTN.UseVisualStyleBackColor = True
        '
        'DeleteBTN
        '
        Me.DeleteBTN.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DeleteBTN.Location = New System.Drawing.Point(346, 251)
        Me.DeleteBTN.Name = "DeleteBTN"
        Me.DeleteBTN.Size = New System.Drawing.Size(96, 29)
        Me.DeleteBTN.TabIndex = 5
        Me.DeleteBTN.Text = "DELETE"
        Me.DeleteBTN.UseVisualStyleBackColor = True
        '
        'AuthorTXT
        '
        Me.AuthorTXT.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AuthorTXT.Location = New System.Drawing.Point(160, 214)
        Me.AuthorTXT.Name = "AuthorTXT"
        Me.AuthorTXT.Size = New System.Drawing.Size(100, 22)
        Me.AuthorTXT.TabIndex = 6
        '
        'PriceTXT
        '
        Me.PriceTXT.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PriceTXT.Location = New System.Drawing.Point(280, 214)
        Me.PriceTXT.Name = "PriceTXT"
        Me.PriceTXT.Size = New System.Drawing.Size(100, 22)
        Me.PriceTXT.TabIndex = 7
        '
        'StockTXT
        '
        Me.StockTXT.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StockTXT.Location = New System.Drawing.Point(402, 214)
        Me.StockTXT.Name = "StockTXT"
        Me.StockTXT.Size = New System.Drawing.Size(100, 22)
        Me.StockTXT.TabIndex = 8
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(32, 198)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(87, 16)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "BOOK NAME"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(157, 198)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(66, 16)
        Me.Label3.TabIndex = 10
        Me.Label3.Text = "AUTHOR"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(283, 198)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(48, 16)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "PRICE"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(399, 198)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(53, 16)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "STOCK"
        '
        'SearchIDTXT
        '
        Me.SearchIDTXT.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SearchIDTXT.Location = New System.Drawing.Point(69, 41)
        Me.SearchIDTXT.Name = "SearchIDTXT"
        Me.SearchIDTXT.Size = New System.Drawing.Size(100, 22)
        Me.SearchIDTXT.TabIndex = 13
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 41)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(51, 16)
        Me.Label1.TabIndex = 14
        Me.Label1.Text = "Search"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(551, 312)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.SearchIDTXT)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.StockTXT)
        Me.Controls.Add(Me.PriceTXT)
        Me.Controls.Add(Me.AuthorTXT)
        Me.Controls.Add(Me.DeleteBTN)
        Me.Controls.Add(Me.UpdateBTN)
        Me.Controls.Add(Me.AddBTN)
        Me.Controls.Add(Me.NameTXT)
        Me.Controls.Add(Me.Book_Table)
        Me.Name = "Form1"
        Me.Text = "Book Inventory"
        CType(Me.Book_Table, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Book_Table As DataGridView
    Friend WithEvents NameTXT As TextBox
    Friend WithEvents AddBTN As Button
    Friend WithEvents UpdateBTN As Button
    Friend WithEvents DeleteBTN As Button
    Friend WithEvents AuthorTXT As TextBox
    Friend WithEvents PriceTXT As TextBox
    Friend WithEvents StockTXT As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents SearchIDTXT As TextBox
    Friend WithEvents Label1 As Label
End Class
