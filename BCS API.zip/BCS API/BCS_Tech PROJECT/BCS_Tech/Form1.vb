﻿Imports MySql.Data.MySqlClient
Public Class Form1
    Dim MysqlConn As MySqlConnection
    Dim command As MySqlCommand
    Dim READER As MySqlDataReader
    Dim dbDataSetBookInfo As DataTable
    'Global String Declare
    Dim Book_ID As String

    Private Sub Add_Btn_Click(sender As Object, e As EventArgs) Handles AddBTN.Click
        Call MYSQL_CONNECT()

        If NameTXT.Text <> "" And AuthorTXT.Text <> "" And PriceTXT.Text <> "" And StockTXT.Text <> "" Then
            Try
                MysqlConn.Open()
                Dim query As String
                query = "INSERT INTO `bcs_schema`.`book_inventory` (`Book_Name`, `Author`, `Price`, `Stock`) VALUES ('" & NameTXT.Text & "', '" & AuthorTXT.Text & "', '" & PriceTXT.Text & "', '" & StockTXT.Text & "');"
                command = New MySqlCommand(query, MysqlConn)
                READER = command.ExecuteReader
                MysqlConn.Close()
                MessageBox.Show("Record Has Been Added")
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try

        Else
            MessageBox.Show("Please Complete the form")
        End If
        Call Load_Book_Table()

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Load_Book_Table()

    End Sub

    Private Sub Load_Book_Table()
        Call MYSQL_CONNECT()

        Dim SDA As New MySqlDataAdapter
        Dim dbDataSet As New DataTable
        Dim bSource As New BindingSource
        Try
            MysqlConn.Open()
            Dim query As String
            query = "SELECT * FROM bcs_schema.book_inventory;"
            command = New MySqlCommand(query, MysqlConn)
            SDA.SelectCommand = command
            SDA.Fill(dbDataSet)
            bSource.DataSource = dbDataSet
            Book_Table.DataSource = bSource
            SDA.Update(dbDataSet)
            MysqlConn.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            MysqlConn.Dispose()
        End Try
        dbDataSetBookInfo = dbDataSet
    End Sub

    Public Sub MYSQL_CONNECT()

        MysqlConn = New MySqlConnection
        MysqlConn.ConnectionString =
        "server=localhost;userid=root;password=root;database=bcs_schema"

    End Sub

    Private Sub Filter_Table()
        Dim DV As New DataView(dbDataSetBookInfo)
        DV.RowFilter = String.Format("Book_Name Like '%{0}%' OR Author Like '%{1}%' OR Price Like '%{2}%' OR Stock Like '%{3}%' ", SearchIDTXT.Text, SearchIDTXT.Text, SearchIDTXT.Text, SearchIDTXT.Text)
        Book_Table.DataSource = DV
    End Sub


    Private Sub Book_Table_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles Book_Table.CellClick
        'Loads The content to TextBoxes
        Call MYSQL_CONNECT()

        If e.RowIndex >= 0 Then
            Dim row As DataGridViewRow
            row = Me.Book_Table.Rows(e.RowIndex)
            Book_ID = row.Cells("Book_ID").Value.ToString
        End If

        Try
            MysqlConn.Open()
            Dim query As String
            Dim id As Integer = 100
            query = "SELECT * FROM bcs_schema.book_inventory WHERE Book_ID = '" & Book_ID & "' "
            command = New MySqlCommand(query, MysqlConn)
            READER = command.ExecuteReader

            While READER.Read

                NameTXT.Text = READER.GetString("Book_Name")
                AuthorTXT.Text = READER.GetString("Author")
                PriceTXT.Text = READER.GetString("Price")
                StockTXT.Text = READER.GetString("Stock")

            End While
            MysqlConn.Close()

        Catch ex As MySqlException
            MessageBox.Show(ex.Message)
        Finally
            MysqlConn.Dispose()
        End Try
    End Sub

    Private Sub UpdateBTN_Click(sender As Object, e As EventArgs) Handles UpdateBTN.Click
        Call MYSQL_CONNECT()

        If Book_ID <> "" Then
            Try
                MysqlConn.Open()
                Dim query As String
                query = "UPDATE `bcs_schema`.`book_inventory` SET `Book_Name`='" & NameTXT.Text & "', `Author`='" & AuthorTXT.Text & "', `Price`='" & PriceTXT.Text & "', `Stock`='" & StockTXT.Text & "' WHERE `Book_ID`='" & Book_ID & "';"
                command = New MySqlCommand(query, MysqlConn)
                READER = command.ExecuteReader
                MysqlConn.Close()
                MessageBox.Show("Record Has Been Updated")
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try

        Else
            MessageBox.Show("Please Click Data in the Table You Want to Update")
        End If
        Call Load_Book_Table()
    End Sub


    Private Sub SearchIDTXT_TextChanged(sender As Object, e As EventArgs) Handles SearchIDTXT.TextChanged
        Call Filter_Table()
    End Sub

    Private Sub DeleteBTN_Click(sender As Object, e As EventArgs) Handles DeleteBTN.Click
        Call MYSQL_CONNECT()
        If Book_ID <> "" Then
            Dim result As Integer = MessageBox.Show("Are You Sure You want to delete this record?", "DELETE!", MessageBoxButtons.YesNo)
            If result = DialogResult.Yes Then
                Try
                    MysqlConn.Open()
                    Dim query As String
                    query = "DELETE FROM `bcs_schema`.`book_inventory` WHERE `Book_ID`='" & Book_ID & "';"
                    command = New MySqlCommand(query, MysqlConn)
                    READER = command.ExecuteReader
                    MysqlConn.Close()
                    MessageBox.Show("Record Has Been Deleted")
                Catch ex As Exception
                    MessageBox.Show(ex.Message)
                End Try
                Call Load_Book_Table()
            ElseIf result = DialogResult.No Then
                MessageBox.Show("Delete of Record has been cancelled")
            End If
        Else
            MessageBox.Show("Please Click Data in the Table You Want to Delete")
        End If
    End Sub
End Class
